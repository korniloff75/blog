<?php
require('../system/global.dat');
require('./include/start.dat');

if($status=='admin'){
	if($act=='index'){
		
		if(isset($_GET['module'])){
			
		$module = $_GET['module'];	
			
		echo'
		<div class="header">
			<h1>Инициализация модуля</h1>
		</div>
		
		<div class="content">		
		<div class="msg">Инициализация модуля завершена.</div>
		</div>
		';
		delldir('../modules/'.$module.'/file');
?>
<script type="text/javascript">
setTimeout('window.location.href = \'index.php\';', 3000);
</script>
<?php	
		}
		
	}
	
}else{
echo'<div class="msg">Необходимо выполнить авторизацию</div>';
?>
<script type="text/javascript">
setTimeout('window.location.href = \'index.php?\';', 3000);
</script>
<?php
}

require('./include/end.dat');
?>