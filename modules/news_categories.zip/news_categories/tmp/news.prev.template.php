<div class="prev-news">
<h2>#header#</h2>
<div class="prev-img">
<img src="#img#" alt="">
</div>
<div class="prev-txt">
#content#
</div>
<div class="icon-prev">
<span class="com"><span class="com-icon"></span> <span class="com-num">#com#</span></span>
<span class="views"><span class="views-icon"></span> <span class="views-num">#views#</span></span>
<span class="yes"><span class="yes-icon"></span> <span class="yes-num">#yes#</span></span>
<span class="no"><span class="no-icon"></span> <span class="no-num">#no#</span></span>
</div>
<div class="data">#date#</div>
<div class="btn-prev"><a href="#uri#">Подробнее</a></div>
</div>