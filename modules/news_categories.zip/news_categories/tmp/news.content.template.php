<div class="news">#content#</div>
<div class="icon-prev">
<span class="com"><span class="com-icon"></span> <span class="com-num">#com#</span></span>
<span class="views"><span class="views-icon"></span> <span class="views-num">#views#</span></span>
<span class="yes" id="yes"><span class="yes-icon"></span> <span class="yes-num">#yes#</span></span>
<span class="no" id="no"><span class="no-icon"></span> <span class="no-num">#no#</span></span>
</div>
<div class="rdm">
<div class="data-news">#date#</div>
<a class="rdm-linkback" href="#" onclick="history.back();return false;" title="Возвращаемся туда, от куда пришли">Вернуться назад</a> 
<a class="rdm-allback" href="#home#">Все новости</a> 
</div>