<div class="prev-news">
<h3>#header#</h3>
<div class="prev-img">
<span style="background:url(#img#) no-repeat;background-size: 100% auto;background-position:50% 50%;"></span>
</div>
<div class="prev-txt">
#content#</div>
<div class="data-news">#date#</div>
<div class="btn-rdm"><a href="#uri#">Подробнее</a></div>
</div>