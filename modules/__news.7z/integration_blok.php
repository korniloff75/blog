<?php
global $Page, $newsStorage, $newsConfig;
return NewsCategory($newsConfig->blokCat, $newsConfig->countInBlok, $newsConfig->blokTemplate);
?>